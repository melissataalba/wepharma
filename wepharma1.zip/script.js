// Vérification du type de fichier uploadé
document.addEventListener("DOMContentLoaded", function () {
    const fileInput = document.getElementById("ordonnance");
    if (fileInput) {
        fileInput.addEventListener("change", function () {
            const allowedTypes = ["application/pdf", "image/jpeg", "image/png"];
            const file = this.files[0];
            if (file && !allowedTypes.includes(file.type)) {
                alert("Seuls les fichiers PDF, JPG et PNG sont autorisés.");
                this.value = "";
            }
        });
    }

    // Validation numéro de sécurité sociale (13 chiffres)
    const secuInput = document.getElementById("secu");
    if (secuInput) {
        secuInput.addEventListener("input", function () {
            this.value = this.value.replace(/[^0-9]/g, '').slice(0, 13);
        });
    }

    // Validation du formulaire à l’envoi (client-side)
    const form = document.querySelector("form");
    if (form) {
        form.addEventListener("submit", function (e) {
            const pharmacie = document.getElementById("pharmacie");
            const paiement = document.getElementById("paiement");

            if (pharmacie && pharmacie.value === "") {
                alert("Veuillez choisir une pharmacie.");
                pharmacie.focus();
                e.preventDefault();
            }

            if (paiement && paiement.value === "") {
                alert("Veuillez choisir un mode de paiement.");
                paiement.focus();
                e.preventDefault();
            }
        });
    }
});
