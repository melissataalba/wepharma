<?php
session_start();
require 'db.php'; // Connexion à la base de données

// Traitement du formulaire de connexion
if (isset($_POST['connexion'])) {
    $email = htmlspecialchars($_POST['email']);
    $password = $_POST['password'];

    // Vérifier l'utilisateur dans la base de données
    $stmt = $pdo->prepare('SELECT * FROM patients WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Connexion réussie
        $_SESSION['patient_id'] = $user['id'];
        $_SESSION['patient_prenom'] = $user['prenom'];

        header('Location: espace_patient.php');
        exit();
    } else {
        $error = "Email ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - WePharma</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <div class="container">
        <a href="index.php" class="logo">
    <img src="assets/logo-wepharma.png" alt="Logo WePharma" class="logo-img">
</a>

        <ul>
            <li><a href="connexion.php">Mon Espace Patient</a></li>
            <li><a href="#">Qui sommes-nous ?</a></li>
            <li><a href="#">Nos Pharmacies</a></li>
        </ul>
    </div>
</nav>

<div class="form-container">
    <h2>Connexion Patient</h2>
    
    <?php if(isset($error)): ?>
        <div class="error-message"><?php echo $error; ?></div>
    <?php endif; ?>

    <form action="connexion.php" method="post">
        <label for="email">Email :</label>
        <input type="email" id="email" name="email" required>

        <label for="password">Mot de passe :</label>
        <input type="password" id="password" name="password" required>

        <button type="submit" name="connexion">Se connecter</button>
    </form>

    <p>Vous n'avez pas de compte ? <a href="inscription.php">Inscrivez-vous ici</a>.</p>
</div>

<footer>
    <div class="container">
        <p>© 2025 WePharma - Tous droits réservés.</p>
    </div>
</footer>

<script src="script.js"></script>
</body>
</html>
