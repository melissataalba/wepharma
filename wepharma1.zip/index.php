<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WePharma - Accueil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- Navbar professionnelle réaliste -->
<nav>
    <div class="container">
        <a href="index.php" class="logo">
    <img src="assets/logo-wepharma.png" alt="Logo WePharma" class="logo-img">
</a>

        <ul>
            <li><a href="connexion.php">Mon Espace Patient</a></li>
            <li><a href="#">Qui sommes-nous ?</a></li>
            <li><a href="#">Nos Pharmacies</a></li>
        </ul>
    </div>
</nav>

<!-- Section d'accueil avec bouton -->
<header>
    <div class="hero">
        <h1>Votre ordonnance facilement envoyée !</h1>
        <p>Envoyez votre ordonnance en quelques clics et récupérez vos médicaments sans attente.</p>
        <a href="connexion.php" class="btn-primary">Envoyer une ordonnance</a>
    </div>
</header>

<!-- Nouvelle section stylée "Nos Services" -->
<section class="services">
    <div class="container">
        <h2>Nos Services</h2>
        <div class="service-boxes">
            <div class="service-card">
                <h3>Click & Collect</h3>
                <p>Choisissez votre pharmacie et récupérez votre commande rapidement.</p>
            </div>
            <div class="service-card">
                <h3>Suivi en temps réel</h3>
                <p>Suivez l'état de votre ordonnance directement sur notre site.</p>
            </div>
        </div>
    </div>
</section>

<!-- Footer réaliste -->
<footer>
    <div class="container">
        <p>© 2025 WePharma - Tous droits réservés.</p>
    </div>
</footer>

<script src="script.js"></script>
</body>
</html>
