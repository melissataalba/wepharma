<?php
session_start();
require 'db.php';

// Authentification simple du pharmacien (peut être améliorée)
$pharmacien_logged = true; // Simulé pour la démo

// Mise à jour du statut si formulaire soumis
if (isset($_POST['maj_statut'])) {
    $commande_id = intval($_POST['commande_id']);
    $nouveau_statut = htmlspecialchars($_POST['statut']);

    $stmt = $pdo->prepare('UPDATE commandes SET statut = ? WHERE id = ?');
    $stmt->execute([$nouveau_statut, $commande_id]);

    $message = "Statut de la commande mis à jour.";
}

// Récupération de toutes les commandes
$stmt = $pdo->query('SELECT c.*, p.prenom, p.nom FROM commandes c
                     JOIN patients p ON c.patient_id = p.id
                     ORDER BY date_envoi DESC');
$commandes = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Interface Pharmacien - WePharma</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <div class="container">
        <a href="index.php" class="logo">
    <img src="assets/logo-wepharma.png" alt="Logo WePharma" class="logo-img">
</a>

        <ul>
            <li><a href="admin_pharmacien.php">Espace Pharmacien</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <h2>Interface Pharmacien – Commandes reçues</h2>

    <?php if (isset($message)): ?>
        <div class="success-message"><?php echo $message; ?></div>
    <?php endif; ?>

    <?php if (count($commandes) > 0): ?>
        <table class="commandes-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Patient</th>
                    <th>Pharmacie</th>
                    <th>Statut</th>
                    <th>Fichier</th>
                    <th>Note</th>
                    <th>SS</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($commandes as $cmd): ?>
                    <tr>
                        <td><?php echo date('d/m/Y H:i', strtotime($cmd['date_envoi'])); ?></td>
                        <td><?php echo htmlspecialchars($cmd['prenom'] . ' ' . $cmd['nom']); ?></td>
                        <td><?php echo htmlspecialchars($cmd['pharmacie']); ?></td>
                        <td><?php echo htmlspecialchars($cmd['statut']); ?></td>
                        <td><a href="uploads/<?php echo urlencode($cmd['fichier']); ?>" target="_blank">Voir</a></td>
                        <td><?php echo nl2br(htmlspecialchars($cmd['note'])); ?></td>
                        <td><?php echo htmlspecialchars($cmd['numero_secu']); ?></td>
                        <td>
                            <form action="admin_pharmacien.php" method="post">
                                <select name="statut" required>
                                    <option value="">Changer statut</option>
                                    <option value="En préparation">En préparation</option>
                                    <option value="Prête à récupérer">Prête à récupérer</option>
                                    <option value="Commande terminée">Commande terminée</option>
                                </select>
                                <input type="hidden" name="commande_id" value="<?php echo $cmd['id']; ?>">
                                <button type="submit" name="maj_statut">Mettre à jour</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucune commande reçue pour le moment.</p>
    <?php endif; ?>
</div>

<footer>
    <div class="container">
        <p>© 2025 WePharma - Tous droits réservés.</p>
    </div>
</footer>

<script src="script.js"></script>
</body>
</html>
