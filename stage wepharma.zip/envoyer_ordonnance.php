<?php
session_start();
require 'db.php';

// Vérifier si le patient est connecté
if (!isset($_SESSION['patient_id'])) {
    header('Location: connexion.php');
    exit();
}

// Traitement du formulaire
if (isset($_POST['envoyer'])) {
    $pharmacie = htmlspecialchars($_POST['pharmacie']);
    $paiement = $_POST['paiement'];
    $note = htmlspecialchars($_POST['note']);
    $secu = htmlspecialchars($_POST['secu']);

    if ($_FILES['ordonnance']['error'] === 0) {
        $nom_fichier = uniqid() . '_' . basename($_FILES['ordonnance']['name']);
        $chemin_fichier = 'uploads/' . $nom_fichier;
        $ext = pathinfo($nom_fichier, PATHINFO_EXTENSION);

        if (in_array(strtolower($ext), ['pdf', 'jpg', 'jpeg', 'png'])) {
            if (move_uploaded_file($_FILES['ordonnance']['tmp_name'], $chemin_fichier)) {
                $stmt = $pdo->prepare("INSERT INTO commandes (patient_id, pharmacie, paiement, statut, note, numero_secu, fichier, date_envoi)
                                       VALUES (?, ?, ?, 'Envoyée', ?, ?, ?, NOW())");
                $stmt->execute([
                    $_SESSION['patient_id'],
                    $pharmacie,
                    $paiement,
                    $note,
                    $secu,
                    $nom_fichier
                ]);
                $message = "Votre ordonnance a bien été envoyée !";
            } else {
                $error = "Erreur lors du téléchargement du fichier.";
            }
        } else {
            $error = "Format de fichier invalide (pdf, jpg, jpeg, png uniquement).";
        }
    } else {
        $error = "Veuillez sélectionner un fichier d’ordonnance.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Envoyer une ordonnance - WePharma</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <div class="container">
       <a href="index.php" class="logo">
    <img src="assets/logo-wepharma.png" alt="Logo WePharma" class="logo-img">
</a>

        <ul>
            <li><a href="espace_patient.php">Retour à l'espace</a></li>
            <li><a href="connexion.php?logout=true">Déconnexion</a></li>
        </ul>
    </div>
</nav>

<div class="form-container">
    <h2>Envoyer une ordonnance</h2>

    <?php if (isset($message)): ?>
        <div class="success-message"><?php echo $message; ?></div>
    <?php elseif (isset($error)): ?>
        <div class="error-message"><?php echo $error; ?></div>
    <?php endif; ?>

    <form action="envoyer_ordonnance.php" method="post" enctype="multipart/form-data">
        <label for="ordonnance">Télécharger votre ordonnance (PDF ou image) :</label>
        <input type="file" name="ordonnance" id="ordonnance" required>

        <label for="note">Message au pharmacien (facultatif) :</label>
        <textarea name="note" id="note" placeholder="Ex : Je souhaite un générique si disponible."></textarea>

        <label for="secu">Numéro de Sécurité Sociale (facultatif) :</label>
        <input type="text" name="secu" id="secu" placeholder="13 chiffres">

        <label for="pharmacie">Choix de la pharmacie (Click & Collect) :</label>
        <select name="pharmacie" id="pharmacie" class="select-pro" required>
            <option value="">-- Sélectionnez une pharmacie --</option>
            <option value="Pharmacie Aubijoux">Pharmacie Aubijoux - Paris 13</option>
            <option value="Pharmacie Centrale du 20ème">Pharmacie Centrale du 20ème - Paris 20</option>
            <option value="Pharmacie de la porte Doree">Pharmacie de la porte Dorée - Paris 12</option>
            <option value="Pharmacie Nguyen Thi-Nhuhang">Pharmacie Nguyen Thi-Nhuhang - Ivry-sur-Seine</option>
            <option value="Pharmacie des Vignerons">Pharmacie des Vignerons - Vincennes</option>
            <option value="Pharmacie du Fort d’aubervilliers">Pharmacie du Fort d’Aubervilliers</option>
            <option value="Pharmacie la Nigelle">Pharmacie la Nigelle - Drancy</option>
            <option value="Pharmacie Colivet">Pharmacie Colivet - Vitry-sur-Seine</option>
            <option value="Pharmacie Balzac">Pharmacie Balzac - Vitry-sur-Seine</option>
            <option value="Pharmacie Jean Moulin">Pharmacie Jean Moulin M & R - Villeneuve-la-Garenne</option>
            <option value="Pharmacie Gare Epinay">Pharmacie Gare Epinay-Villetaneuse</option>
            <option value="Pharmacie Gros Buisson">Pharmacie du Gros Buisson - Epinay</option>
            <option value="Pharmacie Nord Parisien">Pharmacie Nord Parisien - Pierrefitte-sur-Seine</option>
            <option value="Pharmacie Chanzy">Pharmacie de Chanzy - Pavillons-sous-Bois</option>
            <option value="Pharmacie Rougemont">Pharmacie Rougemont - Sevran</option>
            <option value="Pharmacie Jacques Brel">Pharmacie Jacques Brel - Ris-Orangis</option>
            <option value="Pharmacie des Loges">Pharmacie des Loges - Évry-Courcouronnes</option>
            <option value="Pharmacie de Rosny">Pharmacie de Rosny - Rosny-sur-Seine</option>
            <option value="Pharmacie Pont Avignon">Pharmacie du Pont des deux Eaux - Avignon</option>
        </select>

        <label for="paiement">Mode de paiement :</label>
        <select name="paiement" id="paiement" class="select-pro" required>
            <option value="">-- Choisissez un mode de paiement --</option>
            <option value="Sur place">Sur place (CB ou espèces)</option>
            <option value="En ligne">Paiement en ligne (CB)</option>
        </select>

        <!-- ✅ Le bouton était manquant -->
        <button type="submit" name="envoyer">Envoyer l’ordonnance</button>
    </form>
</div>

<footer>
    <div class="container">
        <p>© 2025 WePharma - Tous droits réservés.</p>
    </div>
</footer>

<script src="script.js"></script>
</body>
</html>
