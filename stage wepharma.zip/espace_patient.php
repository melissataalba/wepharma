<?php
session_start();
require 'db.php';

// Vérifie que l'utilisateur est connecté
if (!isset($_SESSION['patient_id'])) {
    header('Location: connexion.php');
    exit();
}

// Récupération du prénom du patient depuis la base de données
$stmt = $pdo->prepare("SELECT prenom FROM patients WHERE id = ?");
$stmt->execute([$_SESSION['patient_id']]);
$patient = $stmt->fetch();

$prenom = $patient ? $patient['prenom'] : '';

// Récupération des ordonnances du patient
$stmt = $pdo->prepare("SELECT * FROM commandes WHERE patient_id = ? ORDER BY date_envoi DESC");
$stmt->execute([$_SESSION['patient_id']]);
$ordonnances = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Espace Patient - WePharma</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <div class="container">
        <a href="index.php" class="logo">
            <img src="assets/logo-wepharma.png" alt="Logo WePharma" class="logo-img">
        </a>
        <ul>
            <li><a href="envoyer_ordonnance.php">Envoyer une ordonnance</a></li>
            <li><a href="connexion.php?logout=true">Déconnexion</a></li>
        </ul>
    </div>
</nav>

<div class="form-container">
    <h2 style="margin-bottom: 30px;">Espace Patient</h2>

    <p style="font-size: 1.2rem; font-weight: bold; margin-bottom: 25px;">
        Bienvenue, <?= htmlspecialchars($prenom) ?> !
    </p>

    <p style="margin-bottom: 20px;">
        <a href="envoyer_ordonnance.php" class="btn-primary">➕ Envoyer une nouvelle ordonnance</a>
    </p>

    <p style="margin-top: 40px; font-weight: bold; font-size: 1.1rem;">📄 Vos ordonnances envoyées :</p>

    <?php if (empty($ordonnances)) : ?>
        <p style="margin-top: 15px;">Vous n'avez envoyé aucune ordonnance pour le moment.</p>
    <?php else : ?>
        <table class="commandes-table">
            <thead>
                <tr>
                    <th>Fichier</th>
                    <th>Pharmacie</th>
                    <th>Date d'envoi</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ordonnances as $o) : ?>
                    <tr>
                        <td><a href="uploads/<?= htmlspecialchars($o['fichier']) ?>" target="_blank">Voir</a></td>
                        <td><?= htmlspecialchars($o['pharmacie']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($o['date_envoi'])) ?></td>
                        <td>
                            <span class="statut statut-<?= strtolower($o['statut']) ?>">
                                <?= htmlspecialchars($o['statut']) ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<footer>
    <div class="container">
        <p>© 2025 WePharma - Tous droits réservés.</p>
    </div>
</footer>

</body>
</html>
