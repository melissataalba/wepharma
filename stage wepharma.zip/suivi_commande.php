<?php
session_start();
require 'db.php';

// Vérifier que le patient est connecté
if (!isset($_SESSION['patient_id'])) {
    header('Location: connexion.php');
    exit();
}

// Vérifier que l'ID de la commande est fourni
if (!isset($_GET['id'])) {
    header('Location: espace_patient.php');
    exit();
}

$commande_id = intval($_GET['id']);

// Vérifier que la commande appartient bien au patient connecté
$stmt = $pdo->prepare('SELECT * FROM commandes WHERE id = ? AND patient_id = ?');
$stmt->execute([$commande_id, $_SESSION['patient_id']]);
$commande = $stmt->fetch();

if (!$commande) {
    header('Location: espace_patient.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Suivi de commande - WePharma</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <div class="container">
        <a href="index.php" class="logo">
    <img src="assets/logo-wepharma.png" alt="Logo WePharma" class="logo-img">
</a>

        <ul>
            <li><a href="espace_patient.php">Mon Espace</a></li>
            <li><a href="connexion.php?logout=true">Déconnexion</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <h2>Suivi de votre commande</h2>

    <div class="commande-details">
        <p><strong>Date d'envoi :</strong> <?php echo date('d/m/Y à H:i', strtotime($commande['date_envoi'])); ?></p>
        <p><strong>Pharmacie choisie :</strong> <?php echo htmlspecialchars($commande['pharmacie']); ?></p>
        <p><strong>Mode de paiement :</strong> <?php echo htmlspecialchars($commande['paiement']); ?></p>
        <p><strong>Statut actuel :</strong> <span class="statut"><?php echo htmlspecialchars($commande['statut']); ?></span></p>

        <?php if (!empty($commande['note'])): ?>
            <p><strong>Message au pharmacien :</strong> <?php echo nl2br(htmlspecialchars($commande['note'])); ?></p>
        <?php endif; ?>

        <?php if (!empty($commande['numero_secu'])): ?>
            <p><strong>Numéro Sécurité Sociale :</strong> <?php echo htmlspecialchars($commande['numero_secu']); ?></p>
        <?php endif; ?>

        <p><strong>Ordonnance :</strong> 
            <a href="uploads/<?php echo urlencode($commande['fichier']); ?>" target="_blank">Voir le fichier</a>
        </p>
    </div>

    <a href="espace_patient.php" class="btn-secondary">← Retour à l'espace patient</a>
</div>

<footer>
    <div class="container">
        <p>© 2025 WePharma - Tous droits réservés.</p>
    </div>
</footer>

<script src="script.js"></script>
</body>
</html>
