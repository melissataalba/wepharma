<?php 
session_start();
require 'db.php';

if (isset($_POST['inscription'])) {
    $prenom = htmlspecialchars($_POST['prenom']);
    $nom = htmlspecialchars($_POST['nom']);
    $email = htmlspecialchars($_POST['email']);
    $telephone = htmlspecialchars($_POST['telephone']);
    $password_raw = $_POST['password'];

    // Vérification de la robustesse du mot de passe
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password_raw)) {
        $error = "Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule et un chiffre.";
    } else {
        $password = password_hash($password_raw, PASSWORD_DEFAULT);

        // Vérification si l'email existe déjà
        $stmt = $pdo->prepare('SELECT id FROM patients WHERE email = ?');
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            $error = "Cet email est déjà utilisé.";
        } else {
            // Insertion sécurisée dans la base de données
            $stmt = $pdo->prepare('INSERT INTO patients (prenom, nom, email, telephone, password) VALUES (?, ?, ?, ?, ?)');
            if ($stmt->execute([$prenom, $nom, $email, $telephone, $password])) {
                $_SESSION['patient_id'] = $pdo->lastInsertId();
                header('Location: espace_patient.php');
                exit();
            } else {
                $error = "Une erreur est survenue. Veuillez réessayer.";
            }
        }
    }
}


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription - WePharma</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <div class="container">
        <a href="index.php" class="logo">
    <img src="assets/logo-wepharma.png" alt="Logo WePharma" class="logo-img">
</a>

        <ul>
            <li><a href="connexion.php">Mon Espace Patient</a></li>
            <li><a href="#">Qui sommes-nous ?</a></li>
            <li><a href="#">Nos Pharmacies</a></li>
        </ul>
    </div>
</nav>

<div class="form-container">
    <h2>Inscription Patient</h2>
    
    <?php if(isset($error)): ?>
        <div class="error-message"><?php echo $error; ?></div>
    <?php endif; ?>

    <form action="inscription.php" method="post">
        <label for="prenom">Prénom :</label>
        <input type="text" id="prenom" name="prenom" required>

        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom" required>

        <label for="email">Email :</label>
        <input type="email" id="email" name="email" required>

        <label for="telephone">Téléphone :</label>
        <input type="tel" id="telephone" name="telephone" required>

        <label for="password">Mot de passe :</label>
        <input type="password" id="password" name="password" required>
        <small style="display:block; margin-top:5px; color: #666;">
         Au moins 8 caractères, une majuscule, une minuscule et un chiffre.
        </small>

        <button type="submit" name="inscription">S'inscrire</button>
    </form>

    <p>Vous avez déjà un compte ? <a href="connexion.php">Connectez-vous ici</a>.</p>
</div>

<footer>
    <div class="container">
        <p>© 2025 WePharma - Tous droits réservés.</p>
    </div>
</footer>

<script src="script.js"></script>
</body>
</html>
