<?php
$host = 'localhost';          // ou 127.0.0.1
$dbname = 'wepharma_db';      // nom de ta base de données
$user = 'root';               // nom d'utilisateur MySQL
$password = '';               // mot de passe MySQL (vide en local par défaut)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
?>
